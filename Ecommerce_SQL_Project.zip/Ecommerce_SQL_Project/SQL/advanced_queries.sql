----------------------------------------------QUESTION----------------------------------------------

-- ADVANCED LEVEL (10 Questions — SQL Comment Format)

	select * from customer;
	select * from products; 
	select * from orderitem;
	select * from orders;
	
-- 1) Find the most profitable product (Revenue = Quantity × PricePerUnit).

	SELECT oi.productid, p.productname,
    SUM(oi.quantity * oi.priceperunit) AS total_revenue
	FROM orderitem oi
	JOIN products p ON oi.productid = p.productid
	GROUP BY oi.productid, p.productname
	ORDER BY total_revenue DESC
	LIMIT 1;

-- 2) Identify the customer who spent the highest total amount.

	SELECT o.customerid,
    c.fullname,
    SUM(o.totalamount) AS total_spent
	FROM orders o
	JOIN customer c ON o.customerid = c.customerid
	GROUP BY o.customerid, c.fullname
	ORDER BY total_spent DESC
	LIMIT 1;

-- 3) Calculate category-wise total revenue.

	SELECT p.category,
    SUM(oi.quantity * oi.priceperunit) AS total_revenue
	FROM orderitem oi
	JOIN products p ON oi.productid = p.productid
	GROUP BY p.category
	ORDER BY total_revenue DESC;

-- 4) Calculate the percentage of repeat customers.
-- Repeat customer = customer with more than 1 order

	WITH customer_orders AS (
    SELECT customerid, COUNT(*) AS order_count
    FROM orders
    GROUP BY customerid),
	repeat_customers AS (
    SELECT COUNT(*) AS repeat_count
    FROM customer_orders
    WHERE order_count > 1),total_customers AS (
    SELECT COUNT(DISTINCT customerid) AS total_count
    FROM orders)
	SELECT (repeat_count::DECIMAL / total_count::DECIMAL) * 100 AS repeat_customer_percentage
	FROM repeat_customers, total_customers;

-- 5) Extract last 6 months sales trend data. (Month + Total Revenue)
	
	SELECT DATE_TRUNC('month', orderdate) AS month,
    SUM(totalamount) AS total_revenue
	FROM orders
	WHERE orderdate >= (CURRENT_DATE - INTERVAL '6 months')
	GROUP BY month
	ORDER BY month;

-- 6) Calculate city-wise average order size (Avg quantity per order).
	
	WITH order_qty AS (
    SELECT oi.orderid,
    SUM(oi.quantity) AS total_quantity
    FROM orderitems oi
    GROUP BY oi.orderid)
	SELECT c.city,
    AVG(oq.total_quantity) AS avg_order_size
	FROM order_qty oq
	JOIN orders o ON oq.orderid = o.orderid
	JOIN customer c ON o.customerid = c.customerid
	GROUP BY c.city
	ORDER BY avg_order_size DESC;

-- 7) Assume 'Processing' orders = Returned orders; calculate return rate %.
-- Return Rate = (Processing Orders / Total Orders) * 100

	SELECT 
    (SUM(CASE WHEN orderstatus = 'Processing' THEN 1 ELSE 0 END)::DECIMAL 
    / COUNT(*)::DECIMAL) * 100 AS return_rate_percentage
	FROM orders;

-- 8) Identify top-performing products and categories by revenue.

-- 8a) Top products by revenue

	SELECT oi.productid, p.productname,
    SUM(oi.quantity * oi.priceperunit) AS total_revenue
	FROM orderitems oi
	JOIN products p ON oi.productid = p.productid
	GROUP BY oi.productid, p.productname
	ORDER BY total_revenue DESC
	LIMIT 10;

-- 8b) Top categories by revenue
	
	SELECT p.category,
    SUM(oi.quantity * oi.priceperunit) AS total_revenue
	FROM orderitems oi
	JOIN products p ON oi.productid = p.productid
	GROUP BY p.category
	ORDER BY total_revenue DESC;

-- 9) Estimate Customer Lifetime Value (CLV) = total revenue per customer.

	SELECT o.customerid, c.fullname,
    SUM(o.totalamount) AS clv
	FROM orders o
	JOIN customer c ON o.customerid = c.customerid
	GROUP BY o.customerid, c.fullname
	ORDER BY clv DESC;

-- 10) Perform year-wise revenue comparison (2023 vs 2024 vs 2025).

	SELECT EXTRACT(YEAR FROM orderdate) AS year,
    SUM(totalamount) AS total_revenue
	FROM orders
	WHERE EXTRACT(YEAR FROM orderdate) IN (2023, 2024, 2025)
	GROUP BY year
	ORDER BY year;
