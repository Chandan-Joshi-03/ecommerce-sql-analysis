----------------------------------------------QUESTION----------------------------------------------

-- BASIC LEVEL (10 Questions)

	select * from customer;
	select * from products; 
	select * from orderitem;
	select * from orders;


-- 1) Count the total number of customers.
	select count (*) as customer_count 
	from customer;

-- 2) List all unique cities where customers are located.
	SELECT distinct city
	FROM customer;
	
-- 3) Find the total number of orders.
	select count (*) as total_order 
	from orders;
	
-- 4) Count how many orders have the status 'Delivered'. 
	select orderid, customerid, orderstatus
	from orders
	where orderstatus = 'Delivered';
	
-- 5) Show the latest 5 orders with OrderID and OrderDate.
	select OrderID, OrderDate 
	from orders limit 5;
	
-- 6) Find the top 10 customers with the highest number of orders.
	select customerid , count( * ) as total_orders
	from orders
	group by customerid
	order by total_orders DESC
	limit 10;
 
-- 7) Calculate the total revenue (SUM of TotalAmount).
	  select sum(totalamount) as total_revenue
	  from orders;
	  
-- 8) List all customers who signed up in 2023.
	select customerid, fullname, signupdate
	as customer_2023
	from customer
	where signupdate between '2023-01-01' and '2023-12-31';
	
-- 9) Count the number of unique product categories.
	select distinct category 
	from products;
	
-- 10) List all products with price_per_unit greater than 9000. 
	select productid, productname
	from products
	where unitprice >  9000;
