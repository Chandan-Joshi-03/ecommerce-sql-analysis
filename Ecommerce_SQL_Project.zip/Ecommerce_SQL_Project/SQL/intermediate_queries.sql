----------------------------------------------QUESTION----------------------------------------------
-- INTERMEDIATE LEVEL (12 Questions)

	select * from customer;
	select * from products; 
	select * from orderitem;
	select * from orders;

-- 1) Count total orders placed by each customer.
	select customerid, 
	count(orderid) as total_order
	from orders
	group by customerid
	order by total_order DESC;

-- 2) Calculate revenue for each city (City + Total Revenue).
	Select c.city, sum(totalamount) as revenue
	from orders o
	join customer c 
	on o.customerid = c.customerid
	group by c.city
	order by revenue desc;

-- 3) Calculate product-wise total quantity sold.
	select productid, 
	sum(quantity) as total_quantity
	from orderitem
	group by productid 
	order by total_quantity DESC;
	 
-- 4) Generate monthly sales trend (Month + Total Revenue).
	select date_trunc('month', orderdate) as month, 
	sum(totalamount) as total_revenue
	from orders
	group by month
	order by month;
	
-- 5) Find the highest-value order with customer, amount, and date.
	select o.orderid,
	o.customerid,
	c.fullname,
	o.orderdate,
	o.totalamount
	from orders o
	join customer c
	on c.customerid = o.customerid
	order by o.totalamount DESC
	LIMIT 1;
	
-- 6) Compare the count of 'Delivered' vs 'Processing' orders.
	select (orderstatus),
	count(*) as totalcount
	from orders
	where orderstatus in ('Delivered', 'Processing')
	group by orderstatus;
-- 7) List customers who placed more than 2 orders.
	select customerid, count(orderid) as morethan
	from orders
	group by customerid
	having count(orderid) > 2
	order by morethan DESC;
	
-- 8) Find category-wise average product price.
	SELECT category,
	avg(unitprice)
	from products
	group by category;



-- 9) List the top 5 most ordered products.
 	select productid,
	sum(quantity) as most_ordered
	from orderitem
	group by productid
	order by most_ordered DESC
	limit 5;
	 
-- 10) Find the top 5 customers based on total spending.
	select o.customerid,
	c.fullname,
	sum(totalamount) as total_amount
	from orders o
	join customer c
	on c.customerid = o.customerid
	GROUP BY o.CustomerID, c.FullName
	order by total_amount DESC
	limit 5;
-- 11) List orders with more than 3 items in orderitems table.
	SELECT OrderID, COUNT(*) AS total_items
	FROM orderitems
	GROUP BY OrderID
	HAVING COUNT(*) > 3;

-- 12) Calculate the Average Order Value (AOV).
	Select 
	AVG(totalamount) as AVERAGE_ORDER_VALUE
	from orders;
