-- import orders csv file from excel 

copy 
orders (OrderID,	CustomerID,	OrderDate,	OrderStatus,	TotalAmount)
from 'D:\e-commerce_anylitics\PNRao_E-commerce_Orders.csv'
DELIMITER ','
CSV HEADER;
