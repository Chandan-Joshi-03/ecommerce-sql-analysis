--import CSV file from Excel

copy 
customer (CustomerID,	FullName,	Email,	SignUpDate,	City,	Country) 
from 'D:\e-commerce_anylitics\PNRao_E-commerce_Customers.csv'
DELIMITER ','
Header CSV ;